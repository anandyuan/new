<?php
header("Content-Type: text/html;charset=utf-8");
    header('Access-Control-Allow-Origin: *');
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
    	$name = "mysql:host=localhost";
$key=$_GET['key'];
 $dbn="mysql:host=localhost;dbname=$base";
 
 
 try{
		$conn=new PDO($dbn,$user,$pwd);
		$sql="insert into `user_key`(`key`) values('$key')";
		$row=$conn->exec($sql);
		echo('成功');
	}catch(PDOExecption $e){
		echo "插入错误，错误原因为：".$e->getMessage()."</br>";
		exit();
	}
?>