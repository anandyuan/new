<?php
$accredit=$_GET['accredit'];
$step=$_GET['step'];
$url='https://ydq.aibushu.com/api/yund51/submit_2';
$post_data['qqUrl']=$accredit;
$post_data['min']=$step;
$post_data['max']=$step;
$post_data['status']=1;
$header = array (
 "Access-Control-Allow-Origin: *",
 "appkey:14cb5940135949d989b08774285e65f5",
 );

 $ch = curl_init();//初始化curl
 curl_setopt($ch, CURLOPT_URL,$url);//抓取指定网页
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//要求结果为字符串且输出到屏幕上
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
 curl_setopt($ch, CURLOPT_POST, 0);//post提交方式
 curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
 $data = curl_exec($ch);//运行curl
 curl_close($ch);
 echo($data);
?>