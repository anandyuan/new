<?php
    header("Content-Type: text/html;charset=utf-8");
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $pwda=$pwd;
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
	$moblie=$_GET['moblie'];
	$password=$_GET['password'];
	echo($fromNam);
    try {
        $pdo = new PDO($dbn,$user,$pwd);
		// echo '数据库连接成功！</br>';
    } catch (PDOException $e) {
       // echo '数据库连接失败！</br>'.$e->getMessage();
        exit();
    }
// 	try{
// 		$conn=new PDO($dbn,$user,$pwd);
// 		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// 		$table="create table xm_user(
// 		student_id int(11) auto_increment primary key,
// 		student_no char(10) not null unique,
// 		student_name char(20) not null)";
// 		$conn->exec($table);
// 		echo "数据表创建成功！</br>";
// 	}catch(PDOException $e) {
//         echo '数据表创建失败！</br>'.$e->getMessage()."</br>";
//         exit();
//     }
		
	$query="select * from xm_user";



	try{
		$conn=new PDO($dbn,$user,$pwd);
		$sql="select * from xm_user";
		$sqla='truncate table user_info';
		$row=1;
		$resulta=$conn->query($sqla);
	//	echo "更新成功！数据表数据为：</br>";
		$result=$conn->query($query);
		foreach($result as $row){
		    $phone=$row["student_no"];
		    $pwd=$row["student_name"];
		    $mid=$row["student_id"];
$server=$row["student_server"];
$inter=mt_rand(1,5);
$step=$row["student_step"];
$urlstr=curPageURL();
if ($step==null) {
$step=mt_rand(25000,40000);
	$url = "$urlstr/api/bf.php?mobile=$phone&password=$pwd&step=$step";
} else {
 	$url = "$urlstr/api/bf.php?mobile=$phone&password=$pwd&step=$step";
}

// $sl_data=array(
// 'uid'=>1,
// 'user_by'=>'get_userinfo',
// 'phoneNum'=>$row["student_no"],
// 'password'=>$row["student_name"],
// 'stepNum'=>32122
// );

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);//要访问的地址
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//执行结果是否被返回，0是返回，1是不返回
curl_setopt($ch, CURLOPT_POST,0);// 发送一个常规的POST请求
$output = curl_exec($ch);//执行并获取数据

curl_close($ch);
if ($server!=null) file_get_contents("https://sc.ftqq.com/$server.send?text=".urlencode($output));

if (strpos($output, "刷取失败")){
		$sql="delete from `xm_user` where student_id='$mid'"; 
		$row=$conn->exec($sql);
}else{

		$conn=new PDO($dbn,$user,$pwda);
		$sql="INSERT INTO `user_info`( `phone`, `status`, `student_step`) VALUES ('$phone','$output','$step')";
		$row=$conn->exec($sql);
    
   echo($output); 
}


		}
	}catch(PDOExecption $e){
		echo "更新错误，错误原因为：".$e->getMessage()."</br>";
		exit();
	}
	
function curPageURL() 
{
  $pageURL = 'http';
 
  if ($_SERVER["HTTPS"] == "on") 
  {
    $pageURL .= "s";
  }
  $pageURL .= "://";
 
  $this_page = $_SERVER["REQUEST_URI"];
   
  // 只取 ? 前面的内容
  if (strpos($this_page, "?") !== false)
  {
    $this_pages = explode("?", $this_page);
    $this_page = reset($this_pages);
  }
 
  if ($_SERVER["SERVER_PORT"] != "80") 
  {
    $pageURL .= $_SERVER["SERVER_NAME"]  ;
  } 
  else
  {
    $pageURL .= $_SERVER["SERVER_NAME"] ;
  }
  return $pageURL;
}	


?>