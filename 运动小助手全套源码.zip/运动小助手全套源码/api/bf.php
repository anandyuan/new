 <?php
header("Content-Type: text/html;charset=utf-8");
	$moblie=$_POST['mobile'];
	$password=$_POST['password'];
	$step=$_POST['step'];
		$moblie=$_GET['mobile'];
	$password=$_GET['password'];
	$step=$_GET['step'];
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
		$conn=new PDO($dbn,$user,$pwd);
		$sql="update num set nums=nums+1";
		$row=$conn->exec($sql);
header('User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36');

function getCode($phone,$password1){
      $url = "https://api-user.huami.com/registrations/+86$phone/tokens";
 $post_data['client_id'] = 'HuaMi';
 $post_data['password'] = $password1;
 $post_data['redirect_uri'] = 'https://s3-us-west-2.amazonaws.com/hm-registration/successsignin.html';
 $post_data['token'] = 'access';
  
 $postUrl = $url;
 $curlPost = $post_data;
 $ch = curl_init();//初始化curl
 curl_setopt($ch, CURLOPT_URL,$postUrl);//抓取指定网页
 curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//要求结果为字符串且输出到屏幕上
 curl_setopt($ch, CURLOPT_POST, 0);//post提交方式
 curl_setopt($ch, CURLOPT_HEADER, true);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
 $data = curl_exec($ch);//运行curl
 curl_close($ch);
 //echo($data.'access');
  $headArr = explode("&", $data);
//print_r($headArr[1]);
$code_str=substr($headArr[1],7);

return $code_str;
}

function setLogin($codee){
 $urll = 'https://account.huami.com/v2/client/login';
 $post_data['app_name'] = 'com.xiaomi.hm.health';
 $post_data['app_version'] = '4.6.0';
 $post_data['code'] = $codee;
 $post_data['country_code'] = 'CN';
 $post_data['device_id'] = '2C8B4939-0CCD-4E94-8CBA-CB8EA6E613A1';
 $post_data['device_model'] = 'phone';
 $post_data['grant_type'] = 'access_token';
 $post_data['third_name'] = 'huami_phone';
  
 $postUrl = $url;
 $curlPost = $post_data;
 $ch = curl_init();//初始化curl
 curl_setopt($ch, CURLOPT_URL,$urll);//抓取指定网页
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//要求结果为字符串且输出到屏幕上
 curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
 curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
 $data = curl_exec($ch);//运行curl
 curl_close($ch);
 //echo($data.'access');
//print_r($headArr[1]);

return $data;
}


function postStep($json_text,$id,$token){
$headers[]='User-Agent:Mozilla/5.0 (iPhone; CPU iPhone OS 13_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/7.0.12(0x17000c2d) NetType/WIFI Language/zh_CN';
$headers[]="apptoken:$token";
    $t=strtotime('now');
 $urll = "https://api-mifit-cn.huami.com/v1/data/band_data.json?&t=$t";
 $post_data['data_json'] = $json_text;
 $post_data['userid'] = $id;
 $post_data['device_type'] = '0';
 $post_data['last_sync_data_time'] = '1589917081';
 $post_data['last_deviceid'] = 'DA932FFFFE8816E7';
//print_r($headers);
  //echo($urll);
 // echo($id);
 $postUrl = $url;
 $curlPost = $post_data;
 $ch = curl_init();//初始化curl
 curl_setopt($ch, CURLOPT_URL,$urll);//抓取指定网页
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//要求结果为字符串且输出到屏幕上
 curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
 curl_setopt($ch, CURLOPT_POST, 0);//post提交方式
 curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
 $data = curl_exec($ch);//运行curl
 curl_close($ch);
 //echo($data.'access');
//print_r($headArr[1]);

return $data;
}

function apptoken($codee){
 $urll = "https://account-cn.huami.com/v1/client/app_tokens?app_name=com.xiaomi.hm.health&dn=api-user.huami.com%2Capi-mifit.huami.com%2Capp-analytics.huami.com&login_token=$codee&os_version=4.1.0";
 $postUrl = $url;
 $curlPost = $post_data;
 $ch = curl_init();//初始化curl
 curl_setopt($ch, CURLOPT_URL,$urll);//抓取指定网页
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//要求结果为字符串且输出到屏幕上
 curl_setopt($ch, CURLOPT_HTTPGET,true);//post提交方式
 $data = curl_exec($ch);//运行curl
 curl_close($ch);
 //echo($data.'access');
//print_r($headArr[1]);
//echo($data);
preg_match('/"app_token":"(.*)","user_id/',$data,$appToken);
//echo($appToken[1]);
return $appToken[1];
}

$code_str=getCode($moblie,$password);
$array=setLogin($code_str);
$headArr = explode(",", $array);

preg_match('/"login_token":"(.*)"/',$headArr[0],$loginToken);
//echo($loginToken[1]);
preg_match('/"user_id":"(.*)"/',$headArr[2],$userid);
$userIDD= $userid[1];
    
$jsontxt=file_get_contents('data_json.txt');
$jsontxt=str_replace('20120',$step,$jsontxt);
$jsontxt=str_replace('2020-10-25',date('Y-m-d', time()),$jsontxt);
$apptoken=apptoken($loginToken[1]);
//echo($jsontxt);

$from_str=postStep($jsontxt,$userIDD,$apptoken);
if (strpos($from_str, "success") === false){
     echo "客户端登录失败";
     return;
}
    echo "成功刷取步数:$step";
 ?>