<?php
    header("Content-Type: text/html;charset=utf-8");
    header('Access-Control-Allow-Origin: *');
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
		$conn=new PDO($dbn,$user,$pwd);
		$sql="select * from num where id=2";
	$smt=$conn->query($sql);
$rows=$smt->fetchAll(PDO::FETCH_ASSOC);
//print_r($rows);
echo($rows[0]['nums'])
		
?>