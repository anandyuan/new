<?php
  header("Content-Type: text/html;charset=utf-8");


$moblie=$_GET['mobile'];
	$pwd=$_GET['password'];
	   $step=$_GET['step'];
	    $token=$_GET['token'];
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwda = $aa[0]['password'];
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
		$conn=new PDO($dbn,$user,$pwda);
		$sql="update num set nums=nums+1";
		$row=$conn->exec($sql);

		$url = "https://bu.txmmp.cn/lx/?mobile=$moblie&pwd=$pwd&step=$step&token=$token";
 $post_data['phone'] = $moblie;
 $post_data['password'] = $pwd;
 $post_data['step'] = $step;
 $post_data['sing'] = '82ef5b0fb9d1333f5ed178df1a709dda';
 
  function RSA($data){
$private_key='-----BEGIN PRIVATE KEY-----
MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBANnt6iMjTdv38dlb
pdswvF2WVzNsuBKTzzIfFhdbZZK4LkGSQINsnn4r2LFPUY3EP6zu2HPTcWFz2v/k
V3zjcxj79zFn0T4yeC4wcJDrL7MCHIDIFCnpq9QlcvJHgxlv+trJ3DNNRrK7oM42
uGscyoQnmlBKMmc4TYhgWmix2GzrAgMBAAECgYBSxea0Seh8sAQQBptMUYp6EWw1
gAm6JKIB64S8gl5mB8ap6R7PzCW2zniTgAj9y5hT2rQj6h+aYCLCJryEFu/TzfTz
/lOMu0tBdK/pz4m4hHMpABzqacIwYqwZbx+MsNzEU+DJhdANUjIeARpOm3tk3CSj
CpM+lXJ9MPYN4igTQQJBAPTXLub2uyHA/3SlV2SIxxQ/BmOnKf0241LKggsKqBGr
W85zEw7qMc+4t3dAH7Xc8/CkJnByh6SMZhDO6SfOd5kCQQDj3LrEPekOvbc6pgKx
7wkSz2TifkBmbIbNWKFSTfMSReYRCaGDQDWy2reQMxAQJeCaQKwZxwT22BpV7dRH
3osjAkBBEI4eQqMoLSm1zdqTlOWSs8z23o2CBPwUHEzCsmpHh8o16s69v+7MzMG0
pw3GPpl08aplZ4o0aDsXbGT5dxzBAkArltkfm1xPFpnLnWBcm4aX05bQASjerxom
hDLwJLtAHqEBV19PVWQwX8jHzAzhme1adM63a6wWcIaxM3rteLQTAkBHhAVd5Y46
Ky/pNH+nlLNOSmOw/B/zi6mySVodG1BxQFjlsoI3NQ/AzI8Ep51bzAQKOp8eg8Sg
kbeM/tg9KHyU
-----END PRIVATE KEY-----';
    //私钥解密 
  $hex_encrypt_data = trim($data);  //十六进制数据
  openssl_private_decrypt(base64_decode($hex_encrypt_data), $decrypt_data, $private_key); //解密数据
  return $decrypt_data;
}
$token=str_replace(' ','+', $token);
$rsanum=floor(RSA($token)/1000);
$bjsz=time()-$rsanum;
if ($bjsz<20) {
 $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);//要访问的地址
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//执行结果是否被返回，0是返回，1是不返回
curl_setopt($ch, CURLOPT_HTTPGET,true);// 发送一个常规的POST请求
//curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
$output = curl_exec($ch);//执行并获取数据
curl_close($ch);
//echo($output);
if(strpos($output, "步数")){
    echo("步数修改成功:$step");
}else if(strpos($output, "check the password")){
    echo("账号密码错误");
}else if(strpos($output, "绑定")){
    echo("绑定失败,请重新提交尝试");
}else{
    echo ("内部错误,请重新尝试,或联系作者");
}
}else{
   echo("别偷我接口了 大锅!!");
    return;
}
// $sl_data=array(
// 'uid'=>1,
// 'user_by'=>'get_userinfo',
// 'phoneNum'=>$row["student_no"],
// 'password'=>$row["student_name"],
// 'stepNum'=>32122
// );


?>