<?php
    header("Content-Type: text/html;charset=utf-8");
    header('Access-Control-Allow-Origin: *');
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
		$conn=new PDO($dbn,$user,$pwd);
		$sql="select * from user_info";
			//$row=$conn->exec($sql);
	$smt=$conn->query($sql);
	$data=$smt->fetchAll();
	foreach ($data as $v){
	    $str='';
	    $str1='';
	     $str2='';
	   $str=substr($v[1],0,3);
	    $str1=substr($v[1],-3);
	    $str2="$str*****$str1";
	    echo $str2.'&nbsp;&nbsp;&nbsp;'.$v[2].'&nbsp;&nbsp;&nbsp;'.$v[3].'<br/>';
	    
	}
//$rows=$smt->fetchAll(PDO::FETCH_ASSOC);

//echo($rows[0]['nums'])

		
?>