<?php
    header("Content-Type: text/html;charset=utf-8");
    header('Access-Control-Allow-Origin: *');
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
	$moblie=$_GET['mobile'];
	$password=$_GET['password'];
$step=$_GET['step'];
	$server=$_GET['server'];
    try {
        $pdo = new PDO($name,$user,$pwd);
	
    } catch (PDOException $e) {
        echo '数据库连接失败！</br>'.$e->getMessage();
        exit();
    }

		
	$query="select * from xm_user";
	
try{
		$conn=new PDO($dbn,$user,$pwd);
		$sql="insert into xm_user(student_id,student_no,student_name,student_step,student_server) values(student_id,'$moblie','$password','$step','$server')";
		$row=$conn->exec($sql);
		$result=$conn->query($query);
		foreach($result as $row){
		
		}
	}catch(PDOExecption $e){
		echo "插入错误，错误原因为：".$e->getMessage()."</br>";
		exit();
	}

	try{
		$conn=new PDO($dbn,$user,$pwd);
		$sql="update xm_user set student_name='$password',student_step='$step',student_server='$server' where student_no='$moblie'";
		$row=$conn->exec($sql);
		echo "更新成功！</br>";
		$result=$conn->query($query);
		foreach($result as $row){
		}
	}catch(PDOExecption $e){
		echo "更新错误，错误原因为：".$e->getMessage()."</br>";
		exit();
	}
	

?>