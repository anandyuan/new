<?php
    header("Content-Type: text/html;charset=utf-8");
    header('Access-Control-Allow-Origin: *');
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
    $key=$_GET['key'];
	$dbn="mysql:host=localhost;dbname=$base";
		$conn=new PDO($dbn,$user,$pwd);
		$sql="DELETE FROM user_key WHERE `key`='$key'";
	$smt=$conn->query($sql);
?>