<?php
  header("Content-Type: text/html;charset=utf-8");
    header('Access-Control-Allow-Origin: *');
    $key=$_GET['key'];
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
		$conn=new PDO($dbn,$user,$pwd);
		$sql="select * from user_key";
        	$smt=$conn->query($sql);
$rows=$smt->fetchAll();
	foreach ($rows as $v){
	    echo($v[1].'<br/>');
	    
	}
?>