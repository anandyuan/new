 <?php
header("Content-Type: text/html;charset=utf-8");
  header('Access-Control-Allow-Origin: *');
	$moblie=$_POST['mobile'];
	$password=$_POST['password'];
	$step=$_POST['step'];
		$moblie=$_GET['mobile'];
	$password=$_GET['password'];
	$inter=$_GET['interface'];
	$step=$_GET['step'];
	$name = "mysql:host=localhost";
            $aa=array(require('database.php')) ;
$bb=print_r($aa,true);
    $user = $aa[0]['username'];
    $pwd = $aa[0]['password'];
    $base=$aa[0]['database'];
	$dbn="mysql:host=localhost;dbname=$base";
		$conn=new PDO($dbn,$user,$pwd);
		$sql="update num set nums=nums+1";
		$row=$conn->exec($sql);
$urlstr=curPageURL();

if ($inter==1) {
    $urll = "$urlstr/api/bf.php?mobile=$moblie&password=$password&step=$step";
}else if ($inter==2) {
	$urll = "$urlstr/api/bf.php?mobile=$moblie&password=$password&step=$step";
}else if ($inter==3) {
    $urll = "$urlstr/api/bf.php?mobile=$moblie&password=$password&step=$step";
}else if ($inter==4) {
    $urll = "$urlstr/api/bf.php?mobile=$moblie&password=$password&step=$step";
}else if ($inter==5) {
    $urll = "$urlstr/api/bf.php?mobile=$moblie&password=$password&step=$step";
}else{
    
}


 $ch = curl_init();//初始化curl
 curl_setopt($ch, CURLOPT_URL,$urll);//抓取指定网页
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);//要求结果为字符串且输出到屏幕上
 curl_setopt($ch, CURLOPT_HTTPGET, true);//post提交方式
 //curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
 $data = curl_exec($ch);//运行curl
 curl_close($ch);
 //echo($data.'access');
//print_r($headArr[1]);
//echo($data);
if (strpos($data, "成功")){
     echo "成功刷取步数:$step";
    
}else if (strpos($data,"success")) {
 echo "成功刷取步数:$step";

}else{
     echo "刷取失败,请更换接口尝试";
}
   ;
function curPageURL() 
{
  $pageURL = 'http';
 
  if ($_SERVER["HTTPS"] == "on") 
  {
    $pageURL .= "s";
  }
  $pageURL .= "://";
 
  $this_page = $_SERVER["REQUEST_URI"];
   
  // 只取 ? 前面的内容
  if (strpos($this_page, "?") !== false)
  {
    $this_pages = explode("?", $this_page);
    $this_page = reset($this_pages);
  }
 
  if ($_SERVER["SERVER_PORT"] != "80") 
  {
    $pageURL .= $_SERVER["SERVER_NAME"]  ;
  } 
  else
  {
    $pageURL .= $_SERVER["SERVER_NAME"] ;
  }
  return $pageURL;
}
 ?>