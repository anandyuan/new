<?php

 function RSA($data){
$private_key='-----BEGIN PRIVATE KEY-----
MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBANnt6iMjTdv38dlb
pdswvF2WVzNsuBKTzzIfFhdbZZK4LkGSQINsnn4r2LFPUY3EP6zu2HPTcWFz2v/k
V3zjcxj79zFn0T4yeC4wcJDrL7MCHIDIFCnpq9QlcvJHgxlv+trJ3DNNRrK7oM42
uGscyoQnmlBKMmc4TYhgWmix2GzrAgMBAAECgYBSxea0Seh8sAQQBptMUYp6EWw1
gAm6JKIB64S8gl5mB8ap6R7PzCW2zniTgAj9y5hT2rQj6h+aYCLCJryEFu/TzfTz
/lOMu0tBdK/pz4m4hHMpABzqacIwYqwZbx+MsNzEU+DJhdANUjIeARpOm3tk3CSj
CpM+lXJ9MPYN4igTQQJBAPTXLub2uyHA/3SlV2SIxxQ/BmOnKf0241LKggsKqBGr
W85zEw7qMc+4t3dAH7Xc8/CkJnByh6SMZhDO6SfOd5kCQQDj3LrEPekOvbc6pgKx
7wkSz2TifkBmbIbNWKFSTfMSReYRCaGDQDWy2reQMxAQJeCaQKwZxwT22BpV7dRH
3osjAkBBEI4eQqMoLSm1zdqTlOWSs8z23o2CBPwUHEzCsmpHh8o16s69v+7MzMG0
pw3GPpl08aplZ4o0aDsXbGT5dxzBAkArltkfm1xPFpnLnWBcm4aX05bQASjerxom
hDLwJLtAHqEBV19PVWQwX8jHzAzhme1adM63a6wWcIaxM3rteLQTAkBHhAVd5Y46
Ky/pNH+nlLNOSmOw/B/zi6mySVodG1BxQFjlsoI3NQ/AzI8Ep51bzAQKOp8eg8Sg
kbeM/tg9KHyU
-----END PRIVATE KEY-----';
    //私钥解密 
  $hex_encrypt_data = trim($data);  //十六进制数据
  openssl_private_decrypt(base64_decode($hex_encrypt_data), $decrypt_data, $private_key); //解密数据
  return $decrypt_data;
}
$token=$_GET['token'];
$token=str_replace(' ','+', $token);
$rsanum=floor(RSA($token)/1000);
$bjsz=time()-$rsanum;
if ($bjsz<20) {

$sn=file_get_contents("quiet_sn.txt");
$arrSn=explode(PHP_EOL,$sn);
//print_r($arrSn);
$ranNum=rand(0,49);
error_reporting(0);
date_default_timezone_set("Etc/GMT-8");
//获取加秒数的时间戳
function getMillisecond() {
list($t1, $t2) = explode(' ', microtime());
return (float)sprintf('%.0f',(floatval($t1)+floatval($t2))*1000);
}
//post函数
function curl($url, $data='', $method='POST',$header){   
    $curl = curl_init(); // 启动一个CURL会话  
    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址  
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 对认证证书来源的检查  
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); // 从证书中检查SSL加密算法是否存在  
    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器  
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转  
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer  
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

    if($method=='POST'){  
        curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求  
        if ($data != ''){  
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包  
        }  
    }  
	curl_setopt($curl, CURLOPT_ENCODING ,'gzip');
    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环  
    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容  
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回  
    $tmpInfo = curl_exec($curl); // 执行操作  
    curl_close($curl); // 关闭CURL会话  
    return $tmpInfo; // 返回数据  
}  
//登录的post，取cookie，Content-Type必须加上
$header = [
'Content-Type: application/json; charset=utf-8',
];
$url="sports.lifesense.com/sessions_service/login?systemType=2&version=4.6.7";
$data = '{"appType":6,"clientId":"88888","loginName":"'.$_GET['mobile'].'","password":"'.md5($_GET['pwd']).'","roleType":0}';

$html = curl($url,$data,$method='POST',$header);
$html=json_decode($html,true);
$userId=$html['data']['userId'];
$step = $_GET['step'];
$accessToken= $html['data']['accessToken'];

if ($accessToken) {
 $url="https://sports.lifesense.com/device_service/device_user/bind";
$header = [
'Cookie: accessToken='.$accessToken,
'Content-Type: application/json; charset=utf-8',
];
$data = '{"qrcode":"'.trim($arrSn[$ranNum]).'"}';
$html=curl($url,$data,$method='POST',$header);
//这两个参数下面的post需要
$html=json_decode($html,true);
$delID=$html['data']['device']['id'];

if ($delID) {
 $url="sports.lifesense.com/sport_service/sport/sport/uploadMobileStepV2?version=4.5&systemType=2";
$header = [
'Cookie: accessToken='.$accessToken,
'Content-Type: application/json; charset=utf-8',
];
//步数距离时间戳都要加上才能成功
$data = '{"list":[{"DataSource":2,"active":1,"calories":"'.intval($step/4).'","dataSource":2,"deviceId":"M_NULL","distance":'.intval($step/3).',"exerciseTime":0,"isUpload":0,"measurementTime":"'.date("Y-m-d H:i:s",time()).'","priority":0,"step":'.$step.',"type":2,"updated":'.getMillisecond().',"userId":'.$userId.'}]}';
$html = curl($url,$data,$method='POST',$header);
$html=json_decode($html,true);
$steps = $html['data']['pedometerRecordHourlyList'][0]['step'];
if(!empty($steps)){
echo '当前步数：'.$step;
$header = [
'Cookie: accessToken='.$accessToken,
'Content-Type: application/json; charset=utf-8',
];
$data = '{"userId":"'.$userId.'","deviceId":"'.$delID.'"}';
$html=curl("https://sports.lifesense.com/device_service/device_user/unbind",$data,$method='POST',$header);
}else if(empty($json[resultObj])){
    echo "哦豁刷步数失败了";
}
}else{
 echo("sn绑定失败,请重试");
}
// 提交步数post

}else{
    echo("Please check the password.");
}
}else{
    echo('你偷毛的接口啊');
}
 ?>